ALTER TABLE entidade_entidade_aud ALTER ent_codconstrutora DROP NOT NULL ;
ALTER TABLE entidade_entidade_aud ALTER ent_codvendedor DROP NOT NULL ;